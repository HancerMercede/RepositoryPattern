
CREATE PROCEDURE ShowCompanyByEmployeeId
   (@Id uniqueidentifier)
AS

BEGIN
SET NOCOUNT ON;

	SELECT C.CompanyId, C.[Name], CONCAT(C.Address,' ', C.Country) AS FullAddress
	   FROM Companies C
	INNER JOIN Employees E ON E.CompanyId = C.CompanyId
	WHERE E.EmployeeId = @Id

END
go

